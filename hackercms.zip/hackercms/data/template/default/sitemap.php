<?php $this->load->view($config['site_template'].'/head');?>
<div class="main">
	<div class="mainleft">
		<div class="lefttop">
			<h3><?=lang('sitemap')?></h3>
		</div>
		<div class="leftmiddle">
			<div class="contact">
			<?=hackercms_fragment('contact')?>
			</div>
		</div>
		<div class="leftbottom"></div>
	</div>
	<div class="mainright">
		<div class="righttop">
			<?=lang('current_location')?><a href="<?=base_url($langurl);?>"><?=lang('home')?></a> > <?=lang('sitemap')?>
		</div>
		<div class="rightmiddle">
			
		
			<div class="view_title" style="text-align:left;"><h2><?=lang('sitemap')?></h2></div>
			<div class="view_con">
				<ul class="sitemap">
				<?php $tmpData = hackercms_allcategory();?>
				<?php foreach ($tmpData as $item): ?>
				<li class="level<?=$item['level']?>"><a href="<?=$item['url']?>"><?=$item['name']?></a></li>
				<?php endforeach;?>
				<?php unset($tmpData,$item);?>
				</ul>
			</div>
		</div>
		<div class="rightbottom"></div>
	</div>
</div>
<?php $this->load->view($config['site_template'].'/foot');?>